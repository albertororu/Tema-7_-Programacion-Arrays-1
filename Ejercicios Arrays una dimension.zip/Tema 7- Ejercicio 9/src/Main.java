import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner datos = new Scanner(System.in);
        int[] numero = new int[8];
        int i;

        System.out.println("Intoduce 8 números enteros, pulsa Intro despues de cada numero introducido");

        for (i = 0; i < 8; i++) {
            numero[i] = datos.nextInt();
        }

        System.out.println();

        for (i = 0; i < 8; i++) {
            if (numero[i] % 2 == 0) {
                System.out.println(numero[i] + " par");
            } else {
                System.out.println(numero[i] + " impar");
            }
        }
    }
}